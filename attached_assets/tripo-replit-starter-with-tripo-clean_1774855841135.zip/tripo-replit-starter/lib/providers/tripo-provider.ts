import { GenerationProvider, GenerationRequest, GenerationSubmission, ProviderTask } from "@/lib/providers/generation-provider";

const DEFAULT_BASE_URL = process.env.TRIPO_BASE_URL?.trim() || "https://api.tripo3d.ai/v2/openapi";

function trimSlash(value: string) {
  return value.replace(/\/$/, "");
}

function assertApiKey(apiKey?: string) {
  if (!apiKey) {
    throw new Error("TRIPO_API_KEY is missing. Add it to your Replit Secrets or .env.");
  }
  if (!apiKey.startsWith("tsk_")) {
    throw new Error("TRIPO_API_KEY must start with 'tsk_'.");
  }
}

function mapModelVersion(qualityPreset: GenerationRequest["qualityPreset"]) {
  switch (qualityPreset) {
    case "draft":
      return "Turbo-v1.0-20250506";
    case "high":
      return "v3.1-20260211";
    case "standard":
    default:
      return "v2.5-20250123";
  }
}

function mapTextureFlags(outputTarget: GenerationRequest["outputTarget"]) {
  if (outputTarget === "printable") {
    return { texture: false, pbr: false, auto_size: true, compress: "geometry", smart_low_poly: true };
  }
  return { texture: true, pbr: true, auto_size: false, compress: null, smart_low_poly: false };
}

function inferFileType(imageUrl: string) {
  const normalized = imageUrl.toLowerCase().split("?")[0];
  if (normalized.endsWith(".png")) return "png";
  if (normalized.endsWith(".webp")) return "webp";
  return "jpeg";
}

type TripoTaskResponse = {
  task_id: string;
  type: string;
  status: ProviderTask["status"];
  progress?: number;
  running_left_time?: number;
  error_code?: number;
  error_msg?: string;
  output?: {
    model?: string;
    base_model?: string;
    pbr_model?: string;
    rendered_image?: string;
  };
};

export class TripoProvider implements GenerationProvider {
  readonly name = "tripo" as const;
  private readonly apiKey: string;
  private readonly baseUrl: string;

  constructor(config?: { apiKey?: string; baseUrl?: string }) {
    this.apiKey = config?.apiKey?.trim() || process.env.TRIPO_API_KEY?.trim() || "";
    assertApiKey(this.apiKey);
    this.baseUrl = trimSlash(config?.baseUrl?.trim() || DEFAULT_BASE_URL);
  }

  private async request<T>(path: string, init?: RequestInit): Promise<T> {
    const response = await fetch(`${this.baseUrl}${path}`, {
      ...init,
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        "Content-Type": "application/json",
        ...(init?.headers ?? {})
      },
      cache: "no-store"
    });

    const payload = (await response.json().catch(() => null)) as { data?: T; code?: number; message?: string } | null;

    if (!response.ok) {
      const message = payload?.message || `Tripo request failed with status ${response.status}.`;
      throw new Error(message);
    }

    if (!payload?.data) {
      throw new Error("Tripo returned an empty response body.");
    }

    return payload.data;
  }

  async submit(request: GenerationRequest): Promise<GenerationSubmission> {
    const flags = mapTextureFlags(request.outputTarget);
    const basePayload = {
      model_version: mapModelVersion(request.qualityPreset),
      texture_quality: request.outputTarget === "preview" ? "detailed" : "standard",
      geometry_quality: request.qualityPreset === "high" ? "detailed" : "standard",
      texture: flags.texture,
      pbr: flags.pbr,
      auto_size: flags.auto_size,
      smart_low_poly: flags.smart_low_poly,
      ...(flags.compress ? { compress: flags.compress } : {})
    } as Record<string, unknown>;

    let payload: Record<string, unknown>;

    if (request.type === "text_to_3d") {
      payload = {
        type: "text_to_model",
        prompt: request.prompt,
        ...basePayload
      };
    } else {
      if (!request.imageUrl) {
        throw new Error("A public image URL is required for image-to-3D generation.");
      }
      payload = {
        type: "image_to_model",
        file: {
          type: inferFileType(request.imageUrl),
          url: request.imageUrl
        },
        orientation: "align_image",
        texture_alignment: "original_image",
        ...basePayload
      };
    }

    const data = await this.request<{ task_id: string }>("/task", {
      method: "POST",
      body: JSON.stringify(payload)
    });

    return {
      provider: this.name,
      providerTaskId: data.task_id,
      primitiveType: null
    };
  }

  async getTask(taskId: string): Promise<ProviderTask> {
    const data = await this.request<TripoTaskResponse>(`/task/${taskId}`, { method: "GET" });
    return {
      provider: this.name,
      taskId: data.task_id,
      status: data.status || "unknown",
      progress: typeof data.progress === "number" ? data.progress : 0,
      modelUrl: data.output?.model ?? null,
      baseModelUrl: data.output?.base_model ?? null,
      pbrModelUrl: data.output?.pbr_model ?? null,
      renderedImageUrl: data.output?.rendered_image ?? null,
      errorMessage: data.error_msg ?? null,
      errorCode: data.error_code ?? null,
      runningLeftTime: data.running_left_time ?? null
    };
  }

  async convertModel(taskId: string, format: "STL"): Promise<GenerationSubmission> {
    const data = await this.request<{ task_id: string }>("/task", {
      method: "POST",
      body: JSON.stringify({
        type: "convert_model",
        original_model_task_id: taskId,
        format,
        flatten_bottom: true,
        pivot_to_center_bottom: true,
        face_limit: 100000,
        bake: false,
        with_animation: false
      })
    });

    return {
      provider: this.name,
      providerTaskId: data.task_id,
      primitiveType: null
    };
  }

  async getBalance(): Promise<{ balance: number; frozen: number }> {
    return this.request<{ balance: number; frozen: number }>("/user/balance", { method: "GET" });
  }
}
