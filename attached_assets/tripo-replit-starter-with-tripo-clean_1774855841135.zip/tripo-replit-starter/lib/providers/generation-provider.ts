import { OutputTarget, PrimitiveType, ProviderName, ProviderTaskStatus, QualityPreset } from "@/lib/types";

export type GenerationRequest = {
  type: "text_to_3d" | "image_to_3d";
  prompt?: string | null;
  imageUrl?: string | null;
  qualityPreset: QualityPreset;
  outputTarget: OutputTarget;
};

export type GenerationSubmission = {
  provider: ProviderName;
  providerTaskId: string;
  primitiveType?: PrimitiveType | null;
};

export type ProviderTask = {
  provider: ProviderName;
  taskId: string;
  status: ProviderTaskStatus;
  progress: number;
  modelUrl?: string | null;
  baseModelUrl?: string | null;
  pbrModelUrl?: string | null;
  renderedImageUrl?: string | null;
  errorMessage?: string | null;
  errorCode?: number | null;
  runningLeftTime?: number | null;
};

export interface GenerationProvider {
  readonly name: ProviderName;
  submit(request: GenerationRequest): Promise<GenerationSubmission>;
  getTask(taskId: string): Promise<ProviderTask>;
  convertModel?(taskId: string, format: "STL"): Promise<GenerationSubmission>;
  getBalance?(): Promise<{ balance: number; frozen: number }>;
}
