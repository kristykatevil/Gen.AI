import { v4 as uuidv4 } from "uuid";
import { pickPrimitive } from "@/lib/shape";
import { GenerationProvider, GenerationRequest, GenerationSubmission, ProviderTask } from "@/lib/providers/generation-provider";

const mockTasks = new Map<string, { createdAt: number; primitiveType: ReturnType<typeof pickPrimitive> }>();

function getProgress(createdAt: number) {
  const ageMs = Date.now() - createdAt;
  if (ageMs < 2000) return { status: "queued" as const, progress: 15 };
  if (ageMs < 5000) return { status: "running" as const, progress: 55 };
  return { status: "success" as const, progress: 100 };
}

export class MockProvider implements GenerationProvider {
  readonly name = "mock" as const;

  async submit(request: GenerationRequest): Promise<GenerationSubmission> {
    const taskId = uuidv4();
    const primitiveType = pickPrimitive(request.prompt, request.imageUrl);
    mockTasks.set(taskId, { createdAt: Date.now(), primitiveType });
    return {
      provider: this.name,
      providerTaskId: taskId,
      primitiveType
    };
  }

  async getTask(taskId: string): Promise<ProviderTask> {
    const task = mockTasks.get(taskId);
    if (!task) {
      return {
        provider: this.name,
        taskId,
        status: "failed",
        progress: 100,
        errorMessage: "Mock task not found."
      };
    }

    const { status, progress } = getProgress(task.createdAt);
    return {
      provider: this.name,
      taskId,
      status,
      progress,
      modelUrl: null,
      renderedImageUrl: null,
      errorMessage: null
    };
  }

  async convertModel(taskId: string): Promise<GenerationSubmission> {
    const source = mockTasks.get(taskId);
    const convertTaskId = uuidv4();
    mockTasks.set(convertTaskId, {
      createdAt: Date.now(),
      primitiveType: source?.primitiveType ?? "box"
    });
    return {
      provider: this.name,
      providerTaskId: convertTaskId,
      primitiveType: source?.primitiveType ?? "box"
    };
  }
}
