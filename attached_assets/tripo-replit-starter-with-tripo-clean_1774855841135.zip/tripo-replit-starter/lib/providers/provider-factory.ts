import { ProviderName } from "@/lib/types";
import { GenerationProvider } from "@/lib/providers/generation-provider";
import { MockProvider } from "@/lib/providers/mock-provider";
import { TripoProvider } from "@/lib/providers/tripo-provider";

export function getGenerationProviderByName(name: ProviderName): GenerationProvider {
  if (name === "tripo") {
    return new TripoProvider();
  }
  return new MockProvider();
}

export function getGenerationProvider(): GenerationProvider {
  const requested = (process.env.GENERATION_PROVIDER || process.env.PROVIDER_MODE || "mock").trim().toLowerCase();
  return getGenerationProviderByName(requested === "tripo" ? "tripo" : "mock");
}
