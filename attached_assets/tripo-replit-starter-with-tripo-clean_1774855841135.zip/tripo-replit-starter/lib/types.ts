export type ProjectStatus = "draft" | "processing" | "ready" | "failed";
export type JobStatus = "queued" | "submitted" | "processing" | "succeeded" | "failed";
export type PrimitiveType = "box" | "sphere" | "cylinder" | "torus" | "cone";
export type ProviderName = "mock" | "tripo";
export type ProviderTaskStatus =
  | "queued"
  | "running"
  | "success"
  | "failed"
  | "cancelled"
  | "banned"
  | "expired"
  | "unknown";

export type QualityPreset = "draft" | "standard" | "high";
export type OutputTarget = "preview" | "printable";
export type SourceType = "text" | "image";

export type Project = {
  id: string;
  name: string;
  sourceType: SourceType;
  prompt: string | null;
  imageUrl: string | null;
  qualityPreset: QualityPreset;
  outputTarget: OutputTarget;
  status: ProjectStatus;
  provider: ProviderName;
  providerTaskId: string | null;
  providerConvertTaskId: string | null;
  providerStatus: ProviderTaskStatus | null;
  primitiveType: PrimitiveType | null;
  progress: number;
  createdAt: string;
  updatedAt: string;
  exportUrl: string | null;
  modelUrl: string | null;
  baseModelUrl: string | null;
  pbrModelUrl: string | null;
  renderedImageUrl: string | null;
  errorMessage: string | null;
};

export type Job = {
  id: string;
  projectId: string;
  sourceType: SourceType;
  prompt: string | null;
  imageUrl: string | null;
  status: JobStatus;
  progress: number;
  qualityPreset: QualityPreset;
  outputTarget: OutputTarget;
  provider: ProviderName;
  providerTaskId: string;
  providerConvertTaskId: string | null;
  providerStatus: ProviderTaskStatus | null;
  primitiveType: PrimitiveType | null;
  modelUrl: string | null;
  baseModelUrl: string | null;
  pbrModelUrl: string | null;
  renderedImageUrl: string | null;
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
  errorMessage: string | null;
};

export type DbShape = {
  projects: Project[];
  jobs: Job[];
};
