import fs from "fs";
import path from "path";
import { v4 as uuidv4 } from "uuid";
import { DbShape, Job, Project, ProviderTaskStatus } from "@/lib/types";
import { createAsciiCubeStl } from "@/lib/shape";
import { getGenerationProviderByName } from "@/lib/providers/provider-factory";

const dbPath = path.join(process.cwd(), "data", "db.json");
const generatedDir = path.join(process.cwd(), "public", "generated");

function ensureDb() {
  if (!fs.existsSync(path.dirname(dbPath))) fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  if (!fs.existsSync(generatedDir)) fs.mkdirSync(generatedDir, { recursive: true });
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify({ projects: [], jobs: [] }, null, 2));
}

function ensureGeneratedStl(projectId: string, projectName: string) {
  const safeName = projectName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || "model";
  const stlFileName = `${projectId}-${safeName}.stl`;
  const stlPath = path.join(generatedDir, stlFileName);
  if (!fs.existsSync(stlPath)) fs.writeFileSync(stlPath, createAsciiCubeStl(safeName));
  return `/generated/${stlFileName}`;
}

export function loadDb(): DbShape {
  ensureDb();
  return JSON.parse(fs.readFileSync(dbPath, "utf-8")) as DbShape;
}

export function saveDb(data: DbShape) {
  ensureDb();
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

export function listProjects(): Project[] {
  const db = loadDb();
  return [...db.projects].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function getProject(projectId: string): Project | undefined {
  return loadDb().projects.find((project) => project.id === projectId);
}

export function createProject(input: Omit<Project, "id" | "createdAt" | "updatedAt">): Project {
  const db = loadDb();
  const now = new Date().toISOString();
  const project: Project = { id: uuidv4(), createdAt: now, updatedAt: now, ...input };
  db.projects.push(project);
  saveDb(db);
  return project;
}

export function createJob(input: Omit<Job, "id" | "createdAt" | "updatedAt" | "completedAt">): Job {
  const db = loadDb();
  const now = new Date().toISOString();
  const job: Job = { id: uuidv4(), createdAt: now, updatedAt: now, completedAt: null, ...input };
  db.jobs.push(job);
  saveDb(db);
  return job;
}

function mapProviderStatusToJobStatus(status: ProviderTaskStatus): Job["status"] {
  switch (status) {
    case "success":
      return "succeeded";
    case "failed":
    case "cancelled":
    case "banned":
    case "expired":
      return "failed";
    case "queued":
      return "submitted";
    case "running":
    case "unknown":
    default:
      return "processing";
  }
}

function applyMockFinalization(db: DbShape, jobIndex: number, projectIndex: number) {
  const job = db.jobs[jobIndex];
  const project = db.projects[projectIndex];
  const exportUrl = ensureGeneratedStl(project.id, project.name);
  db.jobs[jobIndex] = {
    ...job,
    status: "succeeded",
    providerStatus: "success",
    progress: 100,
    completedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  db.projects[projectIndex] = {
    ...project,
    status: "ready",
    providerStatus: "success",
    progress: 100,
    exportUrl,
    updatedAt: new Date().toISOString()
  };
}

export async function syncJob(jobId: string): Promise<Job | undefined> {
  const db = loadDb();
  const jobIndex = db.jobs.findIndex((job) => job.id === jobId);
  if (jobIndex === -1) return undefined;

  const job = db.jobs[jobIndex];
  const projectIndex = db.projects.findIndex((project) => project.id === job.projectId);
  if (projectIndex === -1) return undefined;
  const project = db.projects[projectIndex];

  if (job.provider === "mock") {
    const ageMs = Date.now() - new Date(job.createdAt).getTime();
    if (ageMs < 2000) {
      db.jobs[jobIndex] = { ...job, status: "submitted", providerStatus: "queued", progress: 15, updatedAt: new Date().toISOString() };
      db.projects[projectIndex] = { ...project, status: "processing", providerStatus: "queued", progress: 15, updatedAt: new Date().toISOString() };
    } else if (ageMs < 5000) {
      db.jobs[jobIndex] = { ...job, status: "processing", providerStatus: "running", progress: 55, updatedAt: new Date().toISOString() };
      db.projects[projectIndex] = { ...project, status: "processing", providerStatus: "running", progress: 55, updatedAt: new Date().toISOString() };
    } else {
      applyMockFinalization(db, jobIndex, projectIndex);
    }
    saveDb(db);
    return db.jobs[jobIndex];
  }

  const provider = getGenerationProviderByName(job.provider);

  if (job.providerConvertTaskId) {
    const convertTask = await provider.getTask(job.providerConvertTaskId);
    const convertStatus = mapProviderStatusToJobStatus(convertTask.status);
    const completed = convertTask.status === "success";

    db.jobs[jobIndex] = {
      ...job,
      status: completed ? "succeeded" : convertStatus,
      providerStatus: convertTask.status,
      progress: completed ? 100 : Math.max(70, convertTask.progress || job.progress),
      errorMessage: convertTask.errorMessage ?? null,
      completedAt: completed ? new Date().toISOString() : job.completedAt,
      updatedAt: new Date().toISOString()
    };

    db.projects[projectIndex] = {
      ...project,
      status: completed ? "ready" : convertStatus === "failed" ? "failed" : "processing",
      providerStatus: convertTask.status,
      progress: completed ? 100 : Math.max(70, convertTask.progress || project.progress),
      exportUrl: completed ? convertTask.modelUrl ?? convertTask.baseModelUrl ?? null : project.exportUrl,
      errorMessage: convertTask.errorMessage ?? null,
      updatedAt: new Date().toISOString()
    };

    saveDb(db);
    return db.jobs[jobIndex];
  }

  const task = await provider.getTask(job.providerTaskId);
  const jobStatus = mapProviderStatusToJobStatus(task.status);
  const now = new Date().toISOString();

  db.jobs[jobIndex] = {
    ...job,
    status: task.status === "success" && job.outputTarget === "printable" ? "processing" : jobStatus,
    providerStatus: task.status,
    progress: typeof task.progress === "number" ? task.progress : job.progress,
    modelUrl: task.modelUrl ?? job.modelUrl,
    baseModelUrl: task.baseModelUrl ?? job.baseModelUrl,
    pbrModelUrl: task.pbrModelUrl ?? job.pbrModelUrl,
    renderedImageUrl: task.renderedImageUrl ?? job.renderedImageUrl,
    errorMessage: task.errorMessage ?? null,
    completedAt: task.status === "success" && job.outputTarget !== "printable" ? now : job.completedAt,
    updatedAt: now
  };

  db.projects[projectIndex] = {
    ...project,
    status: task.status === "success" ? (job.outputTarget === "printable" ? "processing" : "ready") : jobStatus === "failed" ? "failed" : "processing",
    providerTaskId: job.providerTaskId,
    providerStatus: task.status,
    progress: typeof task.progress === "number" ? task.progress : project.progress,
    modelUrl: task.modelUrl ?? project.modelUrl,
    baseModelUrl: task.baseModelUrl ?? project.baseModelUrl,
    pbrModelUrl: task.pbrModelUrl ?? project.pbrModelUrl,
    renderedImageUrl: task.renderedImageUrl ?? project.renderedImageUrl,
    errorMessage: task.errorMessage ?? null,
    updatedAt: now
  };

  if (task.status === "success" && job.outputTarget === "printable" && provider.convertModel) {
    const conversion = await provider.convertModel(job.providerTaskId, "STL");
    db.jobs[jobIndex] = {
      ...db.jobs[jobIndex],
      providerConvertTaskId: conversion.providerTaskId,
      status: "processing",
      progress: Math.max(db.jobs[jobIndex].progress, 70),
      updatedAt: new Date().toISOString()
    };
    db.projects[projectIndex] = {
      ...db.projects[projectIndex],
      providerConvertTaskId: conversion.providerTaskId,
      status: "processing",
      progress: Math.max(db.projects[projectIndex].progress, 70),
      updatedAt: new Date().toISOString()
    };
  }

  saveDb(db);
  return db.jobs[jobIndex];
}
