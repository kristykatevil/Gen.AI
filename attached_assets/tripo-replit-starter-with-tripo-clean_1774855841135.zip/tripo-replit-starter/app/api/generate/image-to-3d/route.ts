import fs from "fs";
import path from "path";
import { v4 as uuidv4 } from "uuid";
import { NextResponse } from "next/server";
import { createJob, createProject } from "@/lib/db";
import { getGenerationProvider } from "@/lib/providers/provider-factory";

function getPublicBaseUrl(request: Request) {
  const explicit = process.env.APP_URL?.trim() || process.env.NEXT_PUBLIC_APP_URL?.trim();
  if (explicit) return explicit.replace(/\/$/, "");

  const url = new URL(request.url);
  const protocol = request.headers.get("x-forwarded-proto") || url.protocol.replace(":", "") || "https";
  const host = request.headers.get("x-forwarded-host") || request.headers.get("host") || url.host;
  return `${protocol}://${host}`.replace(/\/$/, "");
}

export async function POST(request: Request) {
  const formData = await request.formData();
  const file = formData.get("image");
  if (!(file instanceof File)) {
    return NextResponse.json({ error: "An image file is required." }, { status: 400 });
  }

  const bytes = Buffer.from(await file.arrayBuffer());
  const ext = path.extname(file.name) || ".png";
  const savedName = `${uuidv4()}${ext}`;
  const uploadDir = path.join(process.cwd(), "public", "uploads");
  const uploadPath = path.join(uploadDir, savedName);
  fs.mkdirSync(uploadDir, { recursive: true });
  fs.writeFileSync(uploadPath, bytes);

  const relativeImageUrl = `/uploads/${savedName}`;
  const absoluteImageUrl = `${getPublicBaseUrl(request)}${relativeImageUrl}`;
  const qualityPreset = (formData.get("qualityPreset")?.toString() ?? "standard") as "draft" | "standard" | "high";
  const outputTarget = (formData.get("outputTarget")?.toString() ?? "printable") as "preview" | "printable";
  const projectName = formData.get("projectName")?.toString().trim() || file.name.replace(/\.[^.]+$/, "");

  try {
    const provider = getGenerationProvider();
    if (provider.name === "tripo" && /localhost|127\.0\.0\.1/.test(absoluteImageUrl)) {
      return NextResponse.json(
        {
          error:
            "Image-to-3D with Tripo needs a public image URL. Set APP_URL or NEXT_PUBLIC_APP_URL to your public Replit URL, or deploy the app first."
        },
        { status: 400 }
      );
    }

    const submission = await provider.submit({
      type: "image_to_3d",
      imageUrl: provider.name === "tripo" ? absoluteImageUrl : relativeImageUrl,
      qualityPreset,
      outputTarget
    });

    const project = createProject({
      name: projectName || "Untitled image model",
      sourceType: "image",
      prompt: null,
      imageUrl: relativeImageUrl,
      qualityPreset,
      outputTarget,
      status: "processing",
      provider: submission.provider,
      providerTaskId: submission.providerTaskId,
      providerConvertTaskId: null,
      providerStatus: "queued",
      primitiveType: submission.primitiveType ?? null,
      progress: 5,
      exportUrl: null,
      modelUrl: null,
      baseModelUrl: null,
      pbrModelUrl: null,
      renderedImageUrl: null,
      errorMessage: null
    });

    const job = createJob({
      projectId: project.id,
      sourceType: "image",
      prompt: null,
      imageUrl: relativeImageUrl,
      status: "submitted",
      progress: 5,
      qualityPreset,
      outputTarget,
      provider: submission.provider,
      providerTaskId: submission.providerTaskId,
      providerConvertTaskId: null,
      providerStatus: "queued",
      primitiveType: submission.primitiveType ?? null,
      modelUrl: null,
      baseModelUrl: null,
      pbrModelUrl: null,
      renderedImageUrl: null,
      errorMessage: null
    });

    return NextResponse.json({ ok: true, projectId: project.id, jobId: job.id, provider: provider.name });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to start image generation.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
