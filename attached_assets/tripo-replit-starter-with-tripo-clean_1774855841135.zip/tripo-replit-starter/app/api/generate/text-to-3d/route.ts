import { NextResponse } from "next/server";
import { createJob, createProject } from "@/lib/db";
import { getGenerationProvider } from "@/lib/providers/provider-factory";

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  if (!body?.prompt || typeof body.prompt !== "string") {
    return NextResponse.json({ error: "A prompt is required." }, { status: 400 });
  }

  try {
    const provider = getGenerationProvider();
    const qualityPreset = body.qualityPreset ?? "standard";
    const outputTarget = body.outputTarget ?? "printable";
    const submission = await provider.submit({
      type: "text_to_3d",
      prompt: body.prompt,
      qualityPreset,
      outputTarget
    });

    const project = createProject({
      name: body.projectName?.trim() || "Untitled text model",
      sourceType: "text",
      prompt: body.prompt,
      imageUrl: null,
      qualityPreset,
      outputTarget,
      status: "processing",
      provider: submission.provider,
      providerTaskId: submission.providerTaskId,
      providerConvertTaskId: null,
      providerStatus: "queued",
      primitiveType: submission.primitiveType ?? null,
      progress: 5,
      exportUrl: null,
      modelUrl: null,
      baseModelUrl: null,
      pbrModelUrl: null,
      renderedImageUrl: null,
      errorMessage: null
    });

    const job = createJob({
      projectId: project.id,
      sourceType: "text",
      prompt: body.prompt,
      imageUrl: null,
      status: "submitted",
      progress: 5,
      qualityPreset,
      outputTarget,
      provider: submission.provider,
      providerTaskId: submission.providerTaskId,
      providerConvertTaskId: null,
      providerStatus: "queued",
      primitiveType: submission.primitiveType ?? null,
      modelUrl: null,
      baseModelUrl: null,
      pbrModelUrl: null,
      renderedImageUrl: null,
      errorMessage: null
    });

    return NextResponse.json({ ok: true, projectId: project.id, jobId: job.id, provider: provider.name });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to start text generation.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
