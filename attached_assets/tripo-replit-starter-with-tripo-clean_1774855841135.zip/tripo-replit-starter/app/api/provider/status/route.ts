import { NextResponse } from "next/server";
import { getGenerationProvider } from "@/lib/providers/provider-factory";

export async function GET() {
  try {
    const provider = getGenerationProvider();
    const balance = provider.getBalance ? await provider.getBalance().catch(() => null) : null;
    return NextResponse.json({
      ok: true,
      provider: provider.name,
      balance,
      hasApiKey: Boolean(process.env.TRIPO_API_KEY),
      appUrlConfigured: Boolean(process.env.APP_URL || process.env.NEXT_PUBLIC_APP_URL)
    });
  } catch (error) {
    const provider = (process.env.GENERATION_PROVIDER || process.env.PROVIDER_MODE || "mock").trim().toLowerCase();
    const message = error instanceof Error ? error.message : "Provider unavailable.";
    return NextResponse.json({ ok: false, provider, error: message }, { status: 500 });
  }
}
