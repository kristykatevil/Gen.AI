import { NextResponse } from "next/server";
import { getProject, syncJob } from "@/lib/db";

export async function GET(_: Request, { params }: { params: { id: string } }) {
  try {
    const job = await syncJob(params.id);
    if (!job) return NextResponse.json({ error: "Job not found." }, { status: 404 });
    const project = getProject(job.projectId);
    return NextResponse.json({ job, project });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to sync job status.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
