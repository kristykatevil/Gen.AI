"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { PrimitiveViewer } from "@/components/PrimitiveViewer";
import { primitiveLabel } from "@/lib/shape";
import { formatDate } from "@/lib/format";
import { Job, Project } from "@/lib/types";

type Props = { initialProject: Project; initialJob: Job | null };

export function ProjectWorkspace({ initialProject, initialJob }: Props) {
  const [project, setProject] = useState<Project>(initialProject);
  const [job, setJob] = useState<Job | null>(initialJob);
  const isComplete = project.status === "ready" || job?.status === "succeeded" || job?.status === "failed";

  useEffect(() => {
    if (!job || isComplete) return;
    let active = true;
    const interval = window.setInterval(async () => {
      const response = await fetch(`/api/jobs/${job.id}`, { cache: "no-store" });
      const payload = await response.json().catch(() => null);
      if (!response.ok || !active || !payload) return;
      setJob(payload.job);
      setProject(payload.project);
      if (payload.job?.status === "succeeded" || payload.job?.status === "failed") window.clearInterval(interval);
    }, 2500);
    return () => {
      active = false;
      window.clearInterval(interval);
    };
  }, [job, isComplete]);

  const primitiveName = useMemo(() => (project.primitiveType ? primitiveLabel(project.primitiveType) : null), [project.primitiveType]);
  const primaryModelUrl = project.modelUrl || project.baseModelUrl || project.pbrModelUrl;

  return (
    <div className="grid grid-2">
      <div className="card">
        <div className="badge">Preview panel</div>
        <h2 style={{ marginTop: 14 }}>{project.name}</h2>
        <p>
          For mock jobs, this panel shows a placeholder primitive. For real Tripo jobs, it shows the rendered preview image when available and exposes the returned model links directly.
        </p>
        {project.renderedImageUrl ? (
          <img src={project.renderedImageUrl} alt={`${project.name} rendered preview`} style={{ width: "100%", borderRadius: 18, display: "block", marginTop: 16 }} />
        ) : project.primitiveType ? (
          <PrimitiveViewer kind={project.primitiveType} />
        ) : (
          <div className="empty" style={{ marginTop: 16 }}>Preview will appear when the provider returns a rendered image.</div>
        )}
      </div>

      <div className="grid" style={{ gap: 18 }}>
        <div className="card">
          <h3>Project status</h3>
          <div className="small" style={{ marginBottom: 12 }}>Created {formatDate(project.createdAt)}</div>
          <div className="progress"><span style={{ width: `${job?.progress ?? project.progress}%` }} /></div>
          <div className="project-meta" style={{ marginTop: 12 }}>
            <span>{job?.status ?? project.status}</span>
            <span>{job?.progress ?? project.progress}%</span>
            <span>{project.qualityPreset}</span>
            <span>{project.outputTarget}</span>
          </div>
        </div>

        <div className="card">
          <h3>Provider result</h3>
          <div className="kv">
            <div className="kv-row"><span>Provider</span><strong>{project.provider}</strong></div>
            <div className="kv-row"><span>Task ID</span><strong>{project.providerTaskId ?? "waiting"}</strong></div>
            <div className="kv-row"><span>Provider status</span><strong>{project.providerStatus ?? "waiting"}</strong></div>
            <div className="kv-row"><span>Preview image</span><strong>{project.renderedImageUrl ? "ready" : "waiting"}</strong></div>
            <div className="kv-row"><span>Primary model</span><strong>{primaryModelUrl ? "ready" : "waiting"}</strong></div>
            <div className="kv-row"><span>Printable export</span><strong>{project.exportUrl ? "ready" : project.outputTarget === "printable" ? "converting" : "not requested"}</strong></div>
          </div>
        </div>

        <div className="card">
          <h3>Model summary</h3>
          <div className="kv">
            <div className="kv-row"><span>Source</span><strong>{project.sourceType}</strong></div>
            <div className="kv-row"><span>Prompt</span><strong>{project.prompt ?? "Image upload"}</strong></div>
            <div className="kv-row"><span>Mock primitive</span><strong>{primitiveName ?? "n/a"}</strong></div>
            <div className="kv-row"><span>Provider error</span><strong>{project.errorMessage ?? "none"}</strong></div>
          </div>
        </div>

        {project.imageUrl ? (
          <div className="card">
            <h3>Input image</h3>
            <img src={project.imageUrl} alt="Project input" style={{ width: "100%", borderRadius: 18, display: "block" }} />
          </div>
        ) : null}

        <div className="card">
          <h3>Actions</h3>
          <div className="cta-row" style={{ flexWrap: "wrap" }}>
            {project.exportUrl ? <a className="button button-primary" href={project.exportUrl} target="_blank" rel="noreferrer">Download STL</a> : <button className="button button-secondary" disabled>{project.outputTarget === "printable" ? "Converting to STL" : "No STL requested"}</button>}
            {primaryModelUrl ? <a className="button button-secondary" href={primaryModelUrl} target="_blank" rel="noreferrer">Open model file</a> : <button className="button button-secondary" disabled>Waiting for model</button>}
            <Link className="button button-secondary" href="/app/create">Create another</Link>
            <Link className="button button-secondary" href="/app">Back to dashboard</Link>
          </div>
          {project.outputTarget === "printable" ? (
            <p className="small" style={{ marginTop: 12 }}>
              Printable jobs first wait for the main generation task, then automatically submit a second Tripo post-process task to convert the model to STL.
            </p>
          ) : null}
        </div>
      </div>
    </div>
  );
}
