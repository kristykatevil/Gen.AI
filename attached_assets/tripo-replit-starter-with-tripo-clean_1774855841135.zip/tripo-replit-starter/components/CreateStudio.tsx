"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type Mode = "text" | "image";
type ProviderStatus = {
  ok: boolean;
  provider: string;
  hasApiKey?: boolean;
  appUrlConfigured?: boolean;
  balance?: { balance: number; frozen: number } | null;
  error?: string;
};

export function CreateStudio() {
  const router = useRouter();
  const [mode, setMode] = useState<Mode>("text");
  const [projectName, setProjectName] = useState("");
  const [prompt, setPrompt] = useState("");
  const [qualityPreset, setQualityPreset] = useState<"draft" | "standard" | "high">("standard");
  const [outputTarget, setOutputTarget] = useState<"preview" | "printable">("printable");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [providerStatus, setProviderStatus] = useState<ProviderStatus | null>(null);

  useEffect(() => {
    let active = true;
    fetch("/api/provider/status", { cache: "no-store" })
      .then(async (response) => ({ ok: response.ok, data: await response.json().catch(() => null) }))
      .then((payload) => {
        if (!active || !payload.data) return;
        setProviderStatus(payload.data as ProviderStatus);
      })
      .catch(() => {
        if (active) setProviderStatus({ ok: false, provider: "unknown", error: "Unable to detect provider status." });
      });

    return () => {
      active = false;
    };
  }, []);

  async function submitText() {
    const response = await fetch("/api/generate/text-to-3d", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ projectName, prompt, qualityPreset, outputTarget })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error ?? "Unable to start text generation.");
    router.push(`/app/projects/${data.projectId}`);
  }

  async function submitImage() {
    const form = new FormData();
    form.append("projectName", projectName);
    form.append("qualityPreset", qualityPreset);
    form.append("outputTarget", outputTarget);
    if (imageFile) form.append("image", imageFile);

    const response = await fetch("/api/generate/image-to-3d", { method: "POST", body: form });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error ?? "Unable to start image generation.");
    router.push(`/app/projects/${data.projectId}`);
  }

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      if (mode === "text") await submitText();
      else await submitImage();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="grid grid-2">
      <form className="card" onSubmit={onSubmit}>
        <div className="badge">Generation studio</div>
        <h2 style={{ marginTop: 14 }}>Create a 3D project</h2>
        <p>
          This starter can now use either the mock engine or a real Tripo task flow. Text-to-3D works with only a server-side API key. Image-to-3D also needs your app to have a public URL so Tripo can fetch the uploaded image.
        </p>
        <div className="cta-row" style={{ marginTop: 8 }}>
          <button className={`button ${mode === "text" ? "button-primary" : "button-secondary"}`} type="button" onClick={() => setMode("text")}>Text to 3D</button>
          <button className={`button ${mode === "image" ? "button-primary" : "button-secondary"}`} type="button" onClick={() => setMode("image")}>Image to 3D</button>
        </div>
        <div style={{ marginTop: 18 }}>
          <label className="label">Project name</label>
          <input className="input" value={projectName} onChange={(event) => setProjectName(event.target.value)} placeholder="Dragon Medallion" />
        </div>
        {mode === "text" ? (
          <div style={{ marginTop: 16 }}>
            <label className="label">Prompt</label>
            <textarea className="textarea" value={prompt} onChange={(event) => setPrompt(event.target.value)} placeholder="Embossed dragon medallion, fantasy style, printable relief" />
          </div>
        ) : (
          <div style={{ marginTop: 16 }}>
            <label className="label">Reference image</label>
            <input className="input" type="file" accept="image/*" onChange={(event) => setImageFile(event.target.files?.[0] ?? null)} />
          </div>
        )}
        <div className="row" style={{ marginTop: 16 }}>
          <div>
            <label className="label">Quality preset</label>
            <select className="select" value={qualityPreset} onChange={(event) => setQualityPreset(event.target.value as "draft" | "standard" | "high")}>
              <option value="draft">Draft</option>
              <option value="standard">Standard</option>
              <option value="high">High</option>
            </select>
          </div>
          <div>
            <label className="label">Output target</label>
            <select className="select" value={outputTarget} onChange={(event) => setOutputTarget(event.target.value as "preview" | "printable")}>
              <option value="printable">Printable</option>
              <option value="preview">Preview</option>
            </select>
          </div>
        </div>
        {error ? <div className="card" style={{ marginTop: 16, borderRadius: 16, padding: 14 }}><strong>Error:</strong> {error}</div> : null}
        <div className="cta-row" style={{ marginTop: 18 }}>
          <button className="button button-primary" disabled={submitting} type="submit">{submitting ? "Starting..." : "Generate project"}</button>
        </div>
      </form>

      <div className="card">
        <div className="badge">Provider status</div>
        <div className="kv" style={{ marginTop: 16 }}>
          <div className="kv-row"><span>Active provider</span><strong>{providerStatus?.provider ?? "loading"}</strong></div>
          <div className="kv-row"><span>Tripo API key</span><strong>{providerStatus?.hasApiKey ? "configured" : "not set"}</strong></div>
          <div className="kv-row"><span>Public app URL</span><strong>{providerStatus?.appUrlConfigured ? "configured" : "not set"}</strong></div>
          <div className="kv-row"><span>Provider balance</span><strong>{providerStatus?.balance ? `${providerStatus.balance.balance} available` : "not loaded"}</strong></div>
        </div>
        <div className="card" style={{ marginTop: 18, borderRadius: 18 }}>
          <h3>Setup for a real Tripo connection</h3>
          <p style={{ marginBottom: 10 }}>
            Add these Replit Secrets before switching the app to the real provider:
          </p>
          <pre style={{ whiteSpace: "pre-wrap", fontSize: 14, margin: 0 }}>GENERATION_PROVIDER=tripo{"\n"}TRIPO_API_KEY=tsk_your_key_here{"\n"}APP_URL=https://your-app-name.your-username.repl.co</pre>
        </div>
        {providerStatus?.error ? <p className="small" style={{ marginTop: 12 }}>Status check error: {providerStatus.error}</p> : null}
      </div>
    </div>
  );
}
