# Tripo-Like 3D Generator Starter for Replit

This is a **Replit-ready starter app** for a Tripo-like product:
- text to 3D
- image to 3D
- async job tracking
- project library
- placeholder preview panel for mock jobs
- automatic STL conversion for printable Tripo jobs
- provider abstraction with **real Tripo API support**

## What changed in this version
This build keeps the mock provider for instant demos, but it also adds a real Tripo integration layer built around the official task flow:
- `POST /task` to create generation tasks
- `GET /task/{task_id}` to poll status
- automatic `convert_model` task submission for STL exports
- server-side API key handling
- provider status route for balance and setup checks

## Run on Replit

### Option A: import from GitHub
1. Put this project in a GitHub repo.
2. In Replit, create a new app using **Import from GitHub**.
3. Replit will read `.replit` and `replit.nix`.
4. Add your Secrets.
5. Click **Run**.

### Option B: upload files into a new Replit Node.js app
1. Create a new Replit app.
2. Replace its files with this project.
3. Add your Secrets.
4. Click **Run**.

The app runs on port `3000` and listens on `0.0.0.0`.

## Replit Secrets / environment variables

### Mock mode
Use this for a zero-dependency demo:

```env
GENERATION_PROVIDER=mock
```

### Real Tripo mode
Use this to hit the live Tripo API:

```env
GENERATION_PROVIDER=tripo
TRIPO_API_KEY=tsk_your_key_here
APP_URL=https://your-public-replit-url.replit.app
```

Notes:
- `APP_URL` must be public for **image-to-3D** because Tripo needs to fetch the uploaded image.
- Text-to-3D does not need a public image URL.
- Keep the API key server-side only.

## Core routes

### Pages
- `/` landing page
- `/app` dashboard
- `/app/create` generation studio
- `/app/projects/[projectId]` result workspace

### API
- `POST /api/generate/text-to-3d`
- `POST /api/generate/image-to-3d`
- `GET /api/projects`
- `GET /api/projects/:id`
- `GET /api/jobs/:id`
- `GET /api/provider/status`

## Data model
The starter still stores local app data in:
- `data/db.json`
- uploaded images in `public/uploads`
- generated mock STL placeholders in `public/generated`

For real Tripo jobs, model and STL downloads come back as provider URLs and are stored in the JSON records.

## How the real provider flow works

### Text to 3D
1. User submits prompt
2. App calls Tripo create-task endpoint
3. Returned task ID is stored locally
4. Project page polls `/api/jobs/:id`
5. Server polls Tripo task status
6. Returned model links and preview image are attached to the project
7. If output target is `printable`, the server submits a Tripo `convert_model` task for STL

### Image to 3D
1. User uploads image
2. App stores image in `public/uploads`
3. App builds a public URL from `APP_URL`
4. Tripo reads the image URL and starts generation
5. The rest of the flow matches text-to-3D

## Next upgrades
1. swap local JSON storage for Postgres or Supabase
2. add auth
3. add Stripe billing
4. replace the preview image panel with a real GLB viewer
5. add object storage and signed URLs
6. add multi-image generation
